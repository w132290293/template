export default {
    meta: {
        title: '页面212222',
        svg: 'vue',
        hidden: true
    },
    // redirect: '/', //重定向
    // alias: '/home', //别名
}