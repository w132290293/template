export default {
    meta: {
        title: '页面2',
        svg: 'vue',
        index: 1
    },
    redirect: '/twoOne/twoTwo', //重定向
    // alias: '/home', //别名
}