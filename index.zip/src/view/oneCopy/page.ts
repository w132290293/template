export default {
    meta: {
        title: '页面11',
        svg: 'vue',
        keepAlive: true,
        index: 2

    },
    // redirect: '/', //重定向
    // alias: '/', //别名
}