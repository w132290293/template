export default {
    meta: {
        title: '页面1',
        svg: 'vue',
        // hidden: true,
        keepAlive: true,
        index: 0
    },
    // redirect: '/', //重定向
    // alias: '/', //别名
}