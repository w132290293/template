export default {
    meta: {
        title: '页面21',
        svg: 'vue',
    },
    // redirect: '/', //重定向
    // alias: '/home', //别名
};